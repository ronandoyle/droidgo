### Example of Servo Functions ###
### User guide at http://www.mindsensors.com/index.php?module=documents&JAS_DocumentManager_op=list

import nxt.locator, time
from nxt.sensor import *

b = nxt.locator.find_one_brick()#find brick and connect
s = MSServo(b, PORT_1)          #which sensor, brick and port to talk to

def showServerInfo():
	print "Battery Level:", 37*(0x00FF & s.get_bat_level()), "mV"
	print "Speed:", s.get_speed(1)
	print "Position:", s.get_position(1)

def servoPositionTest():
	print "Looping through position settings:"
	for i in [1000, 1500, 2000]:
		s.set_position(1,i)
		time.sleep(0.5)
		print "Position:", s.get_position(1)
	
def servoSpeedTest():
	print "Looping through speed settings:"
	for i in [0, 0x10, 0x40, 0x80, 0xA0, 0xC0, 0xFF]:
		s.set_speed(1,i)
		time.sleep(0.5)
		print "Speed:", s.get_speed(1)

showServerInfo()
servoSpeedTest()
servoPositionTest()

#s.set_position(1,2000)
#print "Position:", s.get_position(1)

#s.set_speed(1, 0)   #how to set speed. (motor#, speed value)
#s.set_quick(3, 150) #quick position registers(motor# 1-8, position value 50-250)
#s.command('I3') #sending commands
                #more explanation in user guides, www.mindsensors.com

#for i in range (3):
#    s.set_quick(1, 150)    
#    time.sleep(.5)      #wait .5 seconds
#    s.set_position(1, 1700) #move to position (Motor#, position value 500-2500)

